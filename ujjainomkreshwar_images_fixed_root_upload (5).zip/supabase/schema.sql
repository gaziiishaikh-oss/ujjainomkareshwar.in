-- Ujjain Omkareshwar Traveller: starter schema for shared website data.
-- Run once in Supabase SQL Editor. Do not put a service_role/secret key in browser code.
create table if not exists public.site_data (
  key text primary key,
  value jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now(),
  updated_by uuid references auth.users(id)
);

create table if not exists public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.bookings (
  id uuid primary key default gen_random_uuid(),
  customer_name text not null,
  mobile text not null check (mobile ~ '^[0-9]{10}$'),
  booking_date date not null,
  booking_time time not null,
  pickup text not null,
  destination text not null,
  vehicle text not null default 'Maruti Suzuki Ertiga',
  ac_option text not null check (ac_option in ('AC','Non-AC')),
  booking_type text not null default 'Private Booking',
  journey_type text not null check (journey_type in ('One Way','Round Trip')),
  passengers integer not null default 1 check (passengers between 1 and 7),
  estimated_fare numeric(10,2) not null default 0 check (estimated_fare >= 0),
  advance_amount numeric(10,2) not null default 500 check (advance_amount >= 0),
  special_request text,
  status text not null default 'Pending' check (status in ('Pending','Confirmed','Completed','Cancelled')),
  created_at timestamptz not null default now()
);

alter table public.site_data enable row level security;
alter table public.admin_users enable row level security;
alter table public.bookings enable row level security;

create or replace function public.is_active_admin()
returns boolean language sql stable security definer set search_path = '' as $$
  select exists (
    select 1 from public.admin_users a
    where a.user_id = (select auth.uid()) and a.active = true
  );
$$;

-- Public can read public website settings, but only active admins can change them.
drop policy if exists "Public read site data" on public.site_data;
create policy "Public read site data" on public.site_data for select to anon, authenticated using (true);
drop policy if exists "Admins insert site data" on public.site_data;
create policy "Admins insert site data" on public.site_data for insert to authenticated with check (public.is_active_admin());
drop policy if exists "Admins update site data" on public.site_data;
create policy "Admins update site data" on public.site_data for update to authenticated using (public.is_active_admin()) with check (public.is_active_admin());
drop policy if exists "Admins delete site data" on public.site_data;
create policy "Admins delete site data" on public.site_data for delete to authenticated using (public.is_active_admin());

-- Visitors can submit a booking, but cannot read any booking rows.
drop policy if exists "Public submit booking" on public.bookings;
create policy "Public submit booking" on public.bookings for insert to anon, authenticated with check (
  status = 'Pending' and char_length(customer_name) between 1 and 120
  and mobile ~ '^[0-9]{10}$' and char_length(destination) between 1 and 200
);
drop policy if exists "Admins read bookings" on public.bookings;
create policy "Admins read bookings" on public.bookings for select to authenticated using (public.is_active_admin());
drop policy if exists "Admins update bookings" on public.bookings;
create policy "Admins update bookings" on public.bookings for update to authenticated using (public.is_active_admin()) with check (public.is_active_admin());
drop policy if exists "Admins delete bookings" on public.bookings;
create policy "Admins delete bookings" on public.bookings for delete to authenticated using (public.is_active_admin());

-- Prevent direct public access to the admin allow-list.
revoke all on public.admin_users from anon, authenticated;
grant select, insert, update, delete on public.site_data to anon, authenticated;
grant insert on public.bookings to anon, authenticated;
grant select, update, delete on public.bookings to authenticated;
grant execute on function public.is_active_admin() to authenticated;

-- Public photo bucket. Upload/update/delete will be admin-only after admin auth is connected.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('site-media', 'site-media', true, 10485760, array['image/jpeg','image/png','image/webp','image/avif'])
on conflict (id) do update set public = true, file_size_limit = 10485760,
  allowed_mime_types = array['image/jpeg','image/png','image/webp','image/avif'];

drop policy if exists "Public read site media" on storage.objects;
create policy "Public read site media" on storage.objects for select to anon, authenticated using (bucket_id = 'site-media');
drop policy if exists "Admins upload site media" on storage.objects;
create policy "Admins upload site media" on storage.objects for insert to authenticated with check (bucket_id = 'site-media' and public.is_active_admin());
drop policy if exists "Admins update site media" on storage.objects;
create policy "Admins update site media" on storage.objects for update to authenticated using (bucket_id = 'site-media' and public.is_active_admin()) with check (bucket_id = 'site-media' and public.is_active_admin());
drop policy if exists "Admins delete site media" on storage.objects;
create policy "Admins delete site media" on storage.objects for delete to authenticated using (bucket_id = 'site-media' and public.is_active_admin());

-- Initial public data keys. Values can be updated by the website once its Supabase sync code is configured.
insert into public.site_data(key, value) values
('contacts', '{"call":"919827430197","whatsapp":"919827430197","sms":"919827430197"}'::jsonb),
('routes', '[{"id":"r1","name":"Ujjain → Omkareshwar","oneWay":2200,"twoWay":4000,"extra":200},{"id":"r2","name":"Ujjain → Indore","oneWay":1100,"twoWay":0,"extra":200},{"id":"r3","name":"Indore Airport → Ujjain","oneWay":1100,"twoWay":0,"extra":200},{"id":"r4","name":"Ujjain → Baglamukhi","oneWay":1800,"twoWay":3000,"extra":200},{"id":"r5","name":"Ujjain → Maheshwar","oneWay":0,"twoWay":0,"extra":200}]'::jsonb),
('settings', '{"siteName":"Ujjain Omkareshwar","advance":500,"address":"Near Mahakal Mandir, Galaxy Hotel, Ujjain, Madhya Pradesh","heroHeading":"Comfortable Journey. Peaceful Darshan."}'::jsonb),
('cars', '[{"id":"ertiga","name":"Maruti Suzuki Ertiga","seats":7,"ac":4500,"nonac":4000,"km":15,"photos":["download.jpg"]}]'::jsonb),
('reviews', '[]'::jsonb),
('places', '[]'::jsonb)
on conflict (key) do nothing;
