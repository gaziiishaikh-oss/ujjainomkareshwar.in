const ADMIN_CONFIG = window.ADMIN_CONFIG || {email:"owner@gmail.com", password:"admin123"};
const ADMIN_SESSION_KEY = "ujjainTravellerAdminSession";
const ADMIN_LOCK_KEY = "ujjainTravellerAdminLock";
const ADMIN_MAX_ATTEMPTS = 5;
const STORAGE = "ujjainTravellerV21";
const CONTACTS_KEY = STORAGE+"Contacts";
const BOOKINGS_KEY = STORAGE+"Bookings";
const ROUTES_KEY = STORAGE+"Routes";
const REVIEWS_KEY = STORAGE+"Reviews";
const PLACES_KEY = STORAGE+"FamousPlaces";
const SETTINGS_KEY = STORAGE+"Settings";
const DEFAULT_CONTACTS = {call:"919827430197", whatsapp:"919827430197", sms:"919827430197"};
const DEFAULT_CARS = [{id:"ertiga",name:"Maruti Suzuki Ertiga",seats:7,ac:4500,nonac:4000,km:15,photos:["images/download.jpg"]}];
const DEFAULT_ROUTES = [
  {id:"r1",name:"Ujjain → Omkareshwar",oneWay:2200,twoWay:4000,extra:200},
  {id:"r2",name:"Ujjain → Indore",oneWay:1100,twoWay:0,extra:200},
  {id:"r3",name:"Indore Airport → Ujjain",oneWay:1100,twoWay:0,extra:200},
  {id:"r4",name:"Ujjain → Baglamukhi",oneWay:1800,twoWay:3000,extra:200},
  {id:"r5",name:"Ujjain → Maheshwar",oneWay:0,twoWay:0,extra:200}
];
const DEFAULT_PLACES = [
  {id:"p1",name:"Mahakaleshwar Jyotirlinga",location:"Ujjain",description:"Ujjain's famous Mahakaleshwar Jyotirlinga and one of the city's most important pilgrimage destinations.",photo:"images/ujj 1.jpg"},
  {id:"p2",name:"Harsiddhi Mata Temple",location:"Ujjain",description:"A revered Shakti Peeth and an important spiritual place in Ujjain.",photo:"images/ujjain harisiddhi temple.jpg"},
  {id:"p3",name:"Ram Ghat",location:"Ujjain",description:"Historic ghat on the Shipra River, known for its spiritual atmosphere and evening views.",photo:"images/ramghatr ujjain.jpg"},
  {id:"p4",name:"Bade Ganesh Ji Temple",location:"Ujjain",description:"A popular Lord Ganesha temple near the Mahakal area.",photo:"images/bade-ganeshji.jpg"},
  {id:"p5",name:"Gopal Mandir",location:"Ujjain",description:"A well-known historic temple in the heart of Ujjain.",photo:"images/Gopal-Mandir ujjain(1).webp"},
  {id:"p6",name:"Ujjain Tower Chowk",location:"Ujjain",description:"A recognizable city landmark and busy central area of Ujjain.",photo:"images/tower ujjain1(1).webp"},
  {id:"p7",name:"Ujjain Tower – Night View",location:"Ujjain",description:"A beautiful evening view of Ujjain's iconic tower.",photo:"images/tower ujjain1(1).webp"},
  {id:"p8",name:"Shipra River Ghats",location:"Ujjain",description:"Riverside atmosphere and traditional Ujjain views along the Shipra River.",photo:"images/ujjain3(1).jpg"}
];
const DEFAULT_REVIEWS = [];
const DEFAULT_SETTINGS = {siteName:"Ujjain Omkareshwar",advance:500,address:"Near Mahakal Mandir, Galaxy Hotel, Ujjain, Madhya Pradesh",heroHeading:"Comfortable Journey. Peaceful Darshan."};
let cars = JSON.parse(localStorage.getItem(STORAGE+"Cars")||"null") || DEFAULT_CARS;
let contacts = JSON.parse(localStorage.getItem(CONTACTS_KEY)||"null") || DEFAULT_CONTACTS;
let bookings = JSON.parse(localStorage.getItem(BOOKINGS_KEY)||"[]");
let routes = JSON.parse(localStorage.getItem(ROUTES_KEY)||"null") || DEFAULT_ROUTES;
let reviews = JSON.parse(localStorage.getItem(REVIEWS_KEY)||"null") || DEFAULT_REVIEWS;
let places = JSON.parse(localStorage.getItem(PLACES_KEY)||"null") || DEFAULT_PLACES;
let settings = JSON.parse(localStorage.getItem(SETTINGS_KEY)||"null") || DEFAULT_SETTINGS;
const money=n=>"₹"+Number(n||0).toLocaleString("en-IN");
const save=()=>localStorage.setItem(STORAGE+"Cars",JSON.stringify(cars));
const saveContacts=()=>localStorage.setItem(CONTACTS_KEY,JSON.stringify(contacts));
const saveBookings=()=>localStorage.setItem(BOOKINGS_KEY,JSON.stringify(bookings));
const saveRoutes=()=>localStorage.setItem(ROUTES_KEY,JSON.stringify(routes));
const saveReviews=()=>localStorage.setItem(REVIEWS_KEY,JSON.stringify(reviews));
const savePlaces=()=>localStorage.setItem(PLACES_KEY,JSON.stringify(places));
const saveSettings=()=>localStorage.setItem(SETTINGS_KEY,JSON.stringify(settings));
const esc=s=>String(s??"").replace(/[&<>'"]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[m]));
// Resolve local photos from the repository's images/ folder. Also supports data URLs from admin uploads.
function imagePath(value) {
  const path = String(value || "").trim();
  if (!path) return "";
  if (/^(data:|https?:|blob:)/i.test(path)) return path;
  const filename = path.replace(/^\.\/?images\//i, "").replace(/^images\//i, "").replace(/^\.\//, "");
  return encodeURI(filename);
}
let pendingPhotos = [];


function renderCars(){const box=document.getElementById("carContainer");if(!box)return;box.innerHTML=cars.map(c=>{const photo=imagePath(c.photos?.[0]||"images/download.jpg");return `<div class="car-card"><div class="car-photo" style="background-image:url('${esc(photo)}')"><span>${c.seats} SEATER</span></div><div class="car-details"><h2>${esc(c.name)}</h2><p>Comfortable private travel option for Ujjain and nearby pilgrimage routes.</p><div class="prices"><div><small>AC</small><h3>${money(c.ac)}</h3><p>Ujjain → Omkareshwar</p></div><div><small>NON-AC</small><h3>${money(c.nonac)}</h3><p>Ujjain → Omkareshwar</p></div></div><button class="select-btn" onclick="selectCar('${esc(c.id)}')">Select Car</button></div></div>`}).join("");renderVehicleOptions();}
function renderVehicleOptions(){const v=document.getElementById("vehicle");if(!v)return;const current=v.value;v.innerHTML=cars.map(c=>`<option value="${esc(c.id)}">${esc(c.name)}</option>`).join("");if(cars.some(c=>c.id===current))v.value=current;updateFare();}
function renderPublicRoutes(){const box=document.getElementById("publicRoutes");const dest=document.getElementById("destination");if(box)box.innerHTML=routes.map((r,i)=>`<div class="route-card"><span>${String(i+1).padStart(2,"0")}</span><h3>${esc(r.name)}</h3><p>${r.oneWay?`One-way from ${money(r.oneWay)}`:"Fare on request"}${r.twoWay?` • Round trip ${money(r.twoWay)}`:""}</p><button class="route-book-btn" data-route-name="${esc(r.name)}">Book this route →</button></div>`).join("");if(dest){const current=dest.value;dest.innerHTML=routes.map(r=>`<option>${esc(r.name)}</option>`).join("")+`<option>Custom Route</option>`;if([...dest.options].some(o=>o.value===current))dest.value=current;}document.querySelectorAll(".route-book-btn").forEach(b=>b.onclick=()=>{if(dest){dest.value=b.dataset.routeName;updateFare()}document.getElementById("booking")?.scrollIntoView({behavior:"smooth"})})}
function renderPublicPlaces(){
 const box=document.getElementById("ujjainSlider");
 if(!box)return;
 box.innerHTML=places.map(p=>`<article class="place-card"><img src="${esc(imagePath(p.photo||"images/ujj 1.jpg"))}" alt="${esc(p.name)}"><div class="place-info"><span>${esc(p.location||"Ujjain")}</span><h3>${esc(p.name)}</h3><p>${esc(p.description||"")}</p></div></article>`).join("");
}
function getCar(){return cars.find(c=>c.id===document.getElementById("vehicle")?.value)||cars[0];}
function calculateFare(route, ac, journeyType){if(!route)return 0;let base=Number(journeyType==="Round Trip"?route.twoWay:route.oneWay)||0;if(base&&ac==="AC")base+=Number(route.extra||0);return base;}
function updateFare(){const f=document.getElementById("fare"),ac=document.getElementById("ac")?.value,d=document.getElementById("destination")?.value,journey=document.getElementById("journeyType")?.value||"One Way",r=routes.find(x=>x.name===d);if(f){const base=calculateFare(r,ac,journey);f.textContent=base?money(base):"On Request";}}
function selectCar(id){const v=document.getElementById("vehicle");if(v){v.value=id;updateFare()}document.getElementById("booking")?.scrollIntoView({behavior:"smooth"})} window.selectCar=selectCar;
function bookingMessage(){const c=getCar(),name=document.getElementById("name").value.trim(),mobile=document.getElementById("mobile").value.trim(),date=document.getElementById("date").value,time=document.getElementById("time").value,pickup=document.getElementById("pickup").value,trip=document.getElementById("trip").value,journey=document.getElementById("journeyType")?.value||"One Way",ac=document.getElementById("ac").value,pass=document.getElementById("passengers").value,dest=document.getElementById("destination").value,msg=document.getElementById("message").value.trim();return `🚕 *NEW CAB BOOKING*\n\n👤 *Customer:* ${name}\n📱 *Mobile:* ${mobile}\n📅 *Date:* ${date}\n⏰ *Time:* ${time}\n📍 *Pickup:* ${pickup}\n🛣️ *Destination:* ${dest}\n🚗 *Vehicle:* ${c?.name||"Not selected"}\n❄️ *AC:* ${ac}\n👥 *Passengers:* ${pass}\n🎟️ *Booking Type:* ${trip}\n🔁 *Journey:* ${journey}\n💰 *Estimated Fare:* ${(()=>{const r=routes.find(x=>x.name===dest);const v=calculateFare(r,ac,journey);return v?money(v):"On Request"})()}\n💵 *Advance Required:* ${money(settings.advance)}\n💳 *Balance:* Remaining payment when the car reaches the pickup point.\n📝 *Special Request:* ${msg||"None"}\n\n🏢 *${settings.siteName}*\n📍 ${settings.address}`;}
const form=document.getElementById("bookingForm");form?.addEventListener("submit",async e=>{e.preventDefault();const m=document.getElementById("mobile").value.replace(/\D/g,"");if(m.length!==10){alert("Please enter a valid 10 digit mobile number.");return}const c=getCar(),name=document.getElementById("name").value.trim(),date=document.getElementById("date").value,time=document.getElementById("time").value,pickup=document.getElementById("pickup").value,trip=document.getElementById("trip").value,journey=document.getElementById("journeyType")?.value||"One Way",ac=document.getElementById("ac").value,pass=document.getElementById("passengers").value,destination=document.getElementById("destination").value,message=document.getElementById("message").value.trim();const r=routes.find(x=>x.name===destination);let fare=calculateFare(r,ac,journey);const localBooking={id:Date.now(),name,mobile:m,date,time,pickup,trip,journeyType:journey,ac,passengers:pass,destination,vehicle:c?.name||"",message,estimatedFare:fare,advance:Number(settings.advance||0),createdAt:new Date().toISOString(),status:"Pending"};bookings.unshift(localBooking);saveBookings();renderStats();renderBookings();window.open("https://wa.me/"+contacts.whatsapp+"?text="+encodeURIComponent(bookingMessage()),"_blank")});
window.sendSMS=()=>window.location.href="sms:+"+contacts.sms+"?body="+encodeURIComponent(bookingMessage());
function applyContacts(){const call=contacts.call.replace(/\D/g,"");const wa=contacts.whatsapp.replace(/\D/g,"");const sms=contacts.sms.replace(/\D/g,"");["floatingCall","headerCall","mainCallButton"].forEach(id=>{const el=document.getElementById(id);if(el)el.href="tel:+"+call});const w=document.getElementById("floatingWhatsapp");if(w){w.href="https://wa.me/"+wa;w.target="_blank"}const mw=document.getElementById("mainWhatsappButton");if(mw)mw.href="https://wa.me/"+wa;document.querySelectorAll(".call-number").forEach(x=>x.textContent=call);}
function applySettings(){document.querySelectorAll(".logo h2,.footer-logo h2").forEach(x=>x.textContent=settings.siteName);const h=document.querySelector(".hero h1");if(h&&settings.heroHeading.includes(".")){const [a,...rest]=settings.heroHeading.split(".");h.innerHTML=esc(a)+".<br><span>"+esc(rest.join(".").trim())+"</span>"}document.querySelectorAll(".footer-address").forEach(x=>x.textContent="📍 "+settings.address);const n=document.querySelector(".advance-notice");if(n)n.innerHTML=`<strong>💰 Booking Payment Rule</strong><p>Booking confirm karne ke liye <b>${money(settings.advance)} advance</b> dena hoga. Baaki payment <b>car aapke pickup point par pahunchne par</b> pura dena hoga.</p>`;const pn=document.querySelector(".payment-note");if(pn)pn.innerHTML=`🔐 <b>Advance: ${money(settings.advance)}</b> &nbsp; | &nbsp; Remaining amount: car arrival par.`;}
function renderPublicReviews(){const box=document.getElementById("reviewSlider");const count=document.getElementById("publicReviewCount");const stars=document.getElementById("publicReviewStars");if(!box)return;const verified=reviews.filter(r=>r.verified);if(!verified.length){box.innerHTML='<div class="review-empty"><div>⭐</div><h3>No verified reviews yet</h3><p>Your genuine customer reviews will appear here after you add them from Admin.</p></div>';if(count)count.textContent="No verified reviews yet.";if(stars)stars.textContent="—";return}const avg=verified.reduce((a,r)=>a+Number(r.rating||0),0)/verified.length;if(stars)stars.textContent="★".repeat(Math.round(avg))+"☆".repeat(5-Math.round(avg));if(count)count.textContent=`${verified.length} verified customer review${verified.length===1?"":"s"}`;box.innerHTML=verified.map(r=>`<article class="review-card"><div class="review-head"><div class="review-avatar">${esc((r.name||"C").charAt(0).toUpperCase())}</div><div><h3>${esc(r.name)}</h3><span>${esc(r.source||"Customer")}</span></div><b>✓</b></div><div class="stars">${"★".repeat(Number(r.rating||5))}${"☆".repeat(5-Number(r.rating||5))}</div><p>“${esc(r.text)}”</p><small>✓ Verified customer feedback${r.bookingId?` • ${esc(r.bookingId)}`:""}</small></article>`).join("");}

["vehicle","ac","destination","journeyType"].forEach(id=>document.getElementById(id)?.addEventListener("change",updateFare));
function openAdmin(){document.getElementById("adminModal").setAttribute("aria-hidden","false")}function closeAdmin(){document.getElementById("adminModal").setAttribute("aria-hidden","true")}
document.getElementById("openAdmin")?.addEventListener("click",openAdmin);document.getElementById("closeAdmin")?.addEventListener("click",closeAdmin);document.getElementById("adminModal")?.addEventListener("click",e=>{if(e.target.id==="adminModal")closeAdmin()});
function getAdminLock(){try{return JSON.parse(localStorage.getItem(ADMIN_LOCK_KEY)||"null")}catch{return null}}
function setAdminLock(v){localStorage.setItem(ADMIN_LOCK_KEY,JSON.stringify(v))}
function adminLocked(){const lock=getAdminLock();return lock&&lock.until>Date.now()}

document.getElementById("adminLogin")?.addEventListener("click",()=>{
  const email=document.getElementById("adminEmail")?.value.trim().toLowerCase();
  const password=document.getElementById("adminPassword")?.value;
  if(adminLocked()){const lock=getAdminLock();alert("Too many failed attempts. Please try again after "+Math.ceil((lock.until-Date.now())/60000)+" minute(s).");return;}
  if(!email||!password){alert("Enter owner email and password.");return;}
  if(email===String(ADMIN_CONFIG.email).toLowerCase() && password===String(ADMIN_CONFIG.password)){
    localStorage.removeItem(ADMIN_LOCK_KEY);
    sessionStorage.setItem(ADMIN_SESSION_KEY,"1");
    document.getElementById("adminLoginBox").hidden=true;
    document.getElementById("adminDashboard").hidden=false;
    const em=document.getElementById("adminUserEmail");if(em)em.textContent=ADMIN_CONFIG.email;
    const st=document.getElementById("cloudSecurityState");if(st)st.textContent="Local owner login active";
    renderAdmin();setStatus("Admin login successful.");
  }else{
    const lock=getAdminLock()||{attempts:0};lock.attempts++;
    if(lock.attempts>=ADMIN_MAX_ATTEMPTS){lock.until=Date.now()+15*60*1000;setAdminLock(lock);alert("Too many failed attempts. Admin login is locked for 15 minutes.");}
    else{setAdminLock(lock);alert("Invalid admin email or password. Attempts remaining: "+(ADMIN_MAX_ATTEMPTS-lock.attempts));}
  }
});

document.getElementById("adminResetPassword")?.addEventListener("click",()=>{
  alert("This offline/static version does not send real email OTPs. For real OTP password reset, we will add a PHP + MySQL + email backend when you move the site to hosting.");
});

document.getElementById("logoutAdmin")?.addEventListener("click",()=>{
  sessionStorage.removeItem(ADMIN_SESSION_KEY);
  document.getElementById("adminDashboard").hidden=true;
  document.getElementById("adminLoginBox").hidden=false;
  document.getElementById("adminPassword").value="";
});
function renderAdmin(){
 const box=document.getElementById("adminCarList");
 if(box){box.innerHTML=cars.map(c=>`<div class="admin-car-row"><div class="admin-car-main"><img src="${esc(imagePath(c.photos?.[0]||"images/download.jpg"))}" alt=""><div><b>${esc(c.name)}</b><small>${c.seats} seats • ₹${c.km}/km</small></div></div><label>AC ₹<input type="number" data-id="${c.id}" data-field="ac" value="${c.ac}"></label><label>Non-AC ₹<input type="number" data-id="${c.id}" data-field="nonac" value="${c.nonac}"></label><label>₹/KM <input type="number" data-id="${c.id}" data-field="km" value="${c.km}"></label><label>Photos<input type="file" class="edit-photos" data-id="${c.id}" accept="image/*" multiple></label><button class="admin-save-car" data-id="${c.id}">Save</button><button class="admin-delete-car" data-id="${c.id}" ${cars.length<=1?'disabled':''}>Delete</button></div>`).join("");
  box.querySelectorAll(".admin-save-car").forEach(b=>b.onclick=()=>{const c=cars.find(x=>x.id===b.dataset.id);box.querySelectorAll(`[data-id="${c.id}"]`).forEach(el=>{if(el.dataset.field)c[el.dataset.field]=Number(el.value)});save();renderCars();renderAdmin();setStatus("Car price/rate updated successfully.")});
  box.querySelectorAll(".admin-delete-car").forEach(b=>b.onclick=()=>{if(confirm("Delete this car?")){cars=cars.filter(x=>x.id!==b.dataset.id);save();renderCars();renderAdmin();setStatus("Car removed.")}});
  box.querySelectorAll(".edit-photos").forEach(inp=>inp.addEventListener("change",e=>{const c=cars.find(x=>x.id===e.target.dataset.id);const files=[...e.target.files];const arr=[];files.forEach(f=>{const r=new FileReader();r.onload=()=>{arr.push(r.result);if(arr.length===files.length){c.photos=arr;save();renderCars();renderAdmin();setStatus("Car photos updated successfully for this browser demo.")}};r.readAsDataURL(f)})}));
 }
 document.getElementById("callNumber").value=contacts.call.replace(/^91/,"");document.getElementById("whatsappNumber").value=contacts.whatsapp.replace(/^91/,"");document.getElementById("smsNumber").value=contacts.sms.replace(/^91/,"");
 renderPlacesAdmin();renderRoutesAdmin();renderReviewsAdmin();renderSettingsAdmin();renderBookings();renderStats();
}
function renderPlacesAdmin(){
 const box=document.getElementById("adminPlaces");
 if(!box)return;
 box.innerHTML=places.length?places.map((p,i)=>`<div class="admin-place-row" data-place-row="${esc(p.id)}"><div class="admin-place-preview"><img src="${esc(imagePath(p.photo||"images/ujj 1.jpg"))}" alt=""><div><b>${esc(p.name)}</b><small>${esc(p.location||"Ujjain")}</small></div></div><label>Name<input type="text" data-pfield="name" value="${esc(p.name)}"></label><label>Location<input type="text" data-pfield="location" value="${esc(p.location||"")}"></label><label class="place-desc-field">Description<textarea data-pfield="description" rows="2">${esc(p.description||"")}</textarea></label><label>Change Photo<input type="file" class="edit-place-photo" accept="image/*" data-place="${esc(p.id)}"></label><div class="place-row-actions"><button class="admin-place-save" data-place="${esc(p.id)}">Save Changes</button><button class="admin-place-up" data-place="${esc(p.id)}" ${i===0?'disabled':''}>↑</button><button class="admin-place-down" data-place="${esc(p.id)}" ${i===places.length-1?'disabled':''}>↓</button><button class="admin-place-delete" data-place="${esc(p.id)}">Delete</button></div></div>`).join(""):"<p>No famous places added yet.</p>";
 box.querySelectorAll(".admin-place-save").forEach(btn=>btn.onclick=()=>{const id=btn.dataset.place,p=places.find(x=>x.id===id),row=box.querySelector(`[data-place-row="${id}"]`);if(!p||!row)return;row.querySelectorAll("[data-pfield]").forEach(el=>p[el.dataset.pfield]=el.value.trim());savePlaces();renderPublicPlaces();renderPlacesAdmin();setStatus("Famous place updated successfully.")});
 box.querySelectorAll(".edit-place-photo").forEach(inp=>inp.addEventListener("change",e=>{const f=e.target.files[0],id=e.target.dataset.place,p=places.find(x=>x.id===id);if(!f||!p)return;const r=new FileReader();r.onload=()=>{p.photo=r.result;savePlaces();renderPublicPlaces();renderPlacesAdmin();setStatus("Place photo updated successfully for this browser demo.")};r.readAsDataURL(f)}));
 box.querySelectorAll(".admin-place-delete").forEach(btn=>btn.onclick=()=>{if(places.length<=1){alert("Keep at least one famous place.");return}if(confirm("Delete this famous place?")){places=places.filter(x=>x.id!==btn.dataset.place);savePlaces();renderPublicPlaces();renderPlacesAdmin();setStatus("Famous place removed.")}});
 box.querySelectorAll(".admin-place-up,.admin-place-down").forEach(btn=>btn.onclick=()=>{const i=places.findIndex(x=>x.id===btn.dataset.place),dir=btn.classList.contains("admin-place-up")?-1:1;if(i<0||i+dir<0||i+dir>=places.length)return;[places[i],places[i+dir]]=[places[i+dir],places[i]];savePlaces();renderPublicPlaces();renderPlacesAdmin();setStatus("Famous place order updated.")});
}
function renderRoutesAdmin(){const box=document.getElementById("adminRoutes");if(!box)return;box.innerHTML=routes.map(r=>`<div class="admin-route-row"><div><b>${esc(r.name)}</b><small class="route-id">ID: ${esc(r.id)}</small></div><label>One-way ₹<input type="number" data-route="${r.id}" data-rfield="oneWay" value="${r.oneWay}"></label><label>2-way ₹<input type="number" data-route="${r.id}" data-rfield="twoWay" value="${r.twoWay}"></label><label>AC extra ₹<input type="number" data-route="${r.id}" data-rfield="extra" value="${r.extra}"></label><button class="admin-save-route" data-route="${r.id}">Save</button><button class="admin-delete-route" data-route="${r.id}">Delete</button></div>`).join("");box.querySelectorAll(".admin-save-route").forEach(b=>b.onclick=()=>{const r=routes.find(x=>x.id===b.dataset.route);box.querySelectorAll(`[data-route="${r.id}"]`).forEach(el=>{if(el.dataset.rfield)r[el.dataset.rfield]=Math.max(0,Number(el.value)||0)});saveRoutes();renderPublicRoutes();renderRoutesAdmin();setStatus("Route fare updated successfully.")});box.querySelectorAll(".admin-delete-route").forEach(b=>b.onclick=()=>{if(routes.length<=1){alert("Keep at least one route.");return}if(confirm("Delete this route?")){routes=routes.filter(r=>r.id!==b.dataset.route);saveRoutes();renderPublicRoutes();renderRoutesAdmin();setStatus("Route removed successfully.")}})}
function renderReviewsAdmin(){const box=document.getElementById("adminReviews");if(!box)return;box.innerHTML=reviews.length?reviews.map(r=>`<div class="admin-review-row"><div><b>${esc(r.name)}</b><small>${esc(r.source||"Customer")} ${r.bookingId?`• ${esc(r.bookingId)}`:""}</small></div><span>⭐ ${r.rating}</span><span>${esc(r.text)}</span><span>${r.verified?"✓ Verified":"Pending"}</span><button data-review="${r.id}">Delete</button></div>`).join(""):"<p>No reviews added. Add only real customer feedback.</p>";box.querySelectorAll("button").forEach(b=>b.onclick=()=>{reviews=reviews.filter(r=>r.id!==b.dataset.review);saveReviews();renderReviewsAdmin();renderPublicReviews();setStatus("Review removed.")})}
function renderSettingsAdmin(){document.getElementById("siteName").value=settings.siteName;document.getElementById("advanceAmount").value=settings.advance;document.getElementById("siteAddress").value=settings.address;document.getElementById("heroHeading").value=settings.heroHeading;}
function renderBookings(){const box=document.getElementById("adminBookings");if(!box)return;box.innerHTML=bookings.length?bookings.slice(0,100).map(b=>`<div class="booking-row"><b>${esc(b.name||b.customer_name)}</b><span>${esc(b.mobile)}</span><span>${esc(b.date||b.booking_date||"")} ${esc(b.time||b.booking_time||"")}</span><span>${esc(b.destination||"")}</span><select data-booking="${b.cloudId||b.id}" class="booking-status"><option ${b.status==="Pending"?"selected":""}>Pending</option><option ${b.status==="Confirmed"?"selected":""}>Confirmed</option><option ${b.status==="Completed"?"selected":""}>Completed</option><option ${b.status==="Cancelled"?"selected":""}>Cancelled</option></select></div>`).join(""):"<p>No bookings yet.</p>";box.querySelectorAll(".booking-status").forEach(s=>s.onchange=async()=>{const b=bookings.find(x=>String(x.cloudId||x.id)===s.dataset.booking);if(b){b.status=s.value;saveBookings();renderStats();setStatus("Booking status updated.")}})}
function renderStats(){const now=new Date(),today=now.toISOString().slice(0,10),month=now.toISOString().slice(0,7);document.getElementById("statBookings").textContent=bookings.length;document.getElementById("statToday").textContent=bookings.filter(b=>b.createdAt?.slice(0,10)===today).length;document.getElementById("statMonth").textContent=bookings.filter(b=>b.createdAt?.slice(0,7)===month).length}
function setStatus(t){const x=document.getElementById("adminStatus");if(x)x.textContent=t}
document.getElementById("newCarPhotos")?.addEventListener("change", e => {
  const files = [...(e.target.files || [])];
  pendingPhotos = [];
  const preview = document.getElementById("newCarPhotoPreview");
  if (preview) preview.innerHTML = "";
  if (!files.length) return;
  files.forEach(file => {
    const reader = new FileReader();
    reader.onload = () => {
      pendingPhotos.push(reader.result);
      if (preview) preview.insertAdjacentHTML("beforeend", `<img src="${reader.result}" alt="Car photo preview">`);
    };
    reader.readAsDataURL(file);
  });
});
document.getElementById("addCar")?.addEventListener("click",()=>{const name=document.getElementById("newCarName").value.trim();if(!name){alert("Enter car name.");return}cars.push({id:"car-"+Date.now(),name,seats:Number(document.getElementById("newCarSeats").value)||7,ac:Number(document.getElementById("newCarAC").value)||0,nonac:Number(document.getElementById("newCarNonAC").value)||0,km:Number(document.getElementById("newCarKm").value)||0,photos:pendingPhotos.length?pendingPhotos:["images/download.jpg"]});save();pendingPhotos=[];document.getElementById("newCarPhotos").value="";document.getElementById("newCarPhotoPreview").innerHTML="";renderCars();renderAdmin();setStatus("New car added with uploaded photos.")});
document.getElementById("saveContacts")?.addEventListener("click",()=>{const norm=x=>{let n=x.replace(/\D/g,"");if(n.length===10)n="91"+n;return n};contacts={call:norm(document.getElementById("callNumber").value),whatsapp:norm(document.getElementById("whatsappNumber").value),sms:norm(document.getElementById("smsNumber").value)};saveContacts();applyContacts();setStatus("Call, WhatsApp and SMS numbers updated.")});
let pendingPlacePhoto="";
document.getElementById("newPlacePhoto")?.addEventListener("change",e=>{const f=e.target.files[0],preview=document.getElementById("newPlacePhotoPreview");pendingPlacePhoto="";if(!f){if(preview)preview.innerHTML="";return}const r=new FileReader();r.onload=()=>{pendingPlacePhoto=r.result;if(preview)preview.innerHTML=`<img src="${r.result}" alt="Preview">`};r.readAsDataURL(f)});
document.getElementById("addPlace")?.addEventListener("click",()=>{const name=document.getElementById("newPlaceName").value.trim(),location=document.getElementById("newPlaceLocation").value.trim()||"Ujjain",description=document.getElementById("newPlaceDescription").value.trim();if(!name||!description){alert("Enter place name and description.");return}if(!pendingPlacePhoto){alert("Please upload a place photo.");return}places.push({id:"place-"+Date.now(),name,location,description,photo:pendingPlacePhoto});savePlaces();renderPublicPlaces();renderPlacesAdmin();document.getElementById("newPlaceName").value="";document.getElementById("newPlaceLocation").value="";document.getElementById("newPlaceDescription").value="";document.getElementById("newPlacePhoto").value="";document.getElementById("newPlacePhotoPreview").innerHTML="";pendingPlacePhoto="";setStatus("New famous place added successfully.")});
document.getElementById("addRoute")?.addEventListener("click",()=>{const name=document.getElementById("newRouteName").value.trim();if(!name){alert("Enter route name.");return}if(routes.some(r=>r.name.toLowerCase()===name.toLowerCase())){alert("This route already exists.");return}routes.push({id:"route-"+Date.now(),name,oneWay:Math.max(0,Number(document.getElementById("newRouteOneWay").value)||0),twoWay:Math.max(0,Number(document.getElementById("newRouteTwoWay").value)||0),extra:Math.max(0,Number(document.getElementById("newRouteExtra").value)||0)});saveRoutes();renderPublicRoutes();renderRoutesAdmin();document.getElementById("newRouteName").value="";document.getElementById("newRouteOneWay").value=0;document.getElementById("newRouteTwoWay").value=0;document.getElementById("newRouteExtra").value=200;setStatus("New route added successfully.")});
document.getElementById("addReview")?.addEventListener("click",()=>{const name=document.getElementById("reviewName").value.trim(),text=document.getElementById("reviewText").value.trim(),source=document.getElementById("reviewSource").value.trim()||"Customer",bookingId=document.getElementById("reviewBookingId").value.trim(),rating=Math.min(5,Math.max(1,Number(document.getElementById("reviewRating").value)||5)),verified=document.getElementById("reviewVerified").checked;if(!name||!text){alert("Enter the real customer's name and actual review text.");return}if(!verified){alert("For public display, please confirm this is genuine customer feedback by checking the verified box.");return}reviews.unshift({id:"rev-"+Date.now(),name,rating,text,source,bookingId,verified:true});saveReviews();renderReviewsAdmin();renderPublicReviews();document.getElementById("reviewName").value="";document.getElementById("reviewText").value="";document.getElementById("reviewSource").value="";document.getElementById("reviewBookingId").value="";document.getElementById("reviewVerified").checked=false;setStatus("Verified genuine review added.")});
document.getElementById("saveSettings")?.addEventListener("click",()=>{settings={siteName:document.getElementById("siteName").value.trim()||DEFAULT_SETTINGS.siteName,advance:Number(document.getElementById("advanceAmount").value)||500,address:document.getElementById("siteAddress").value.trim()||DEFAULT_SETTINGS.address,heroHeading:document.getElementById("heroHeading").value.trim()||DEFAULT_SETTINGS.heroHeading};saveSettings();applySettings();setStatus("Website settings updated.")});
const slider=document.getElementById("ujjainSlider");document.getElementById("ujjainPrev")?.addEventListener("click",()=>slider?.scrollBy({left:-320,behavior:"smooth"}));document.getElementById("ujjainNext")?.addEventListener("click",()=>slider?.scrollBy({left:320,behavior:"smooth"}));
// Remove legacy Eeco data and old placeholder reviews from older demos.
reviews=reviews.filter(r=>r.verified===true);saveReviews();
cars=cars.filter(c=>!String(c.name).toLowerCase().includes("eeco"));if(!cars.length)cars=DEFAULT_CARS;save();
applyContacts();applySettings();renderCars();renderPublicPlaces();renderPublicRoutes();renderPublicReviews();
